import { useAppTheme } from '@/theme/ThemeContext';
import { spacing, typography } from '@/theme/theme';
import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';

export default function GreetingBanner({ name, totalCount }) {
  const { colors } = useAppTheme();
  const styles = useMemo(() => makeStyles(colors), [colors]);

  return (
    <View style={styles.greetingRow}>
      <Text style={styles.greetingText}>
        Hello {name}
        {'\n'}
        Your total notes are {totalCount}
      </Text>
    </View>
  );
}

const makeStyles = (colors) =>
  StyleSheet.create({
    greetingRow: {
      alignItems: 'flex-start',
      marginTop: spacing.md,
    },
    greetingText: {
      ...typography.label,
      color: colors.text,
    },
  });