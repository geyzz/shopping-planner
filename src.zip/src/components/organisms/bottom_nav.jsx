import { useAppTheme } from '@/theme/ThemeContext';
import { spacing } from '@/theme/theme';
import { Feather } from '@expo/vector-icons';
import { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

const TABS = [
  { key: 'home', label: 'Home', icon: 'home', path: '/screens/home' },
  { key: 'settings', label: 'Profile', icon: 'user', path: '/screens/settings' },
  { key: 'calendar', label: 'Calendar', icon: 'calendar', path: '/screens/calendar' },
];

export default function BottomNavigation({ activeTab, onTabPress }) {
  const { colors } = useAppTheme();
  const styles = useMemo(() => makeStyles(colors), [colors]);

  return (
    <View style={styles.bottomNav}>
      {TABS.map((tab) => {
        const isActive = activeTab === tab.key;
        return (
          <Pressable
            key={tab.key}
            style={styles.navItem}
            onPress={() => onTabPress(tab.path)}
          >
            <Feather
              name={tab.icon}
              size={24}
              color={isActive ? colors.navy : colors.textSecondary}
            />
            <Text style={styles.navLabel}>{tab.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const makeStyles = (colors) =>
  StyleSheet.create({
    bottomNav: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      backgroundColor: colors.white,
      borderTopWidth: 1,
      borderTopColor: colors.border,
      paddingVertical: spacing.sm,
      paddingBottom: spacing.md,
    },
    navItem: {
      alignItems: 'center',
    },
    navLabel: {
      fontSize: 11,
      color: colors.textSecondary,
      marginTop: 2,
    },
  });